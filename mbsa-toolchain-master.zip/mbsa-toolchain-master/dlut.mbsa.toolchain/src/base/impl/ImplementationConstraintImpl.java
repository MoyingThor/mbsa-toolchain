/**
 */
package base.impl;

import base.Base_Package;
import base.ImplementationConstraint;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Implementation Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ImplementationConstraintImpl extends UtilityElementImpl implements ImplementationConstraint {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ImplementationConstraintImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Base_Package.Literals.IMPLEMENTATION_CONSTRAINT;
	}

} //ImplementationConstraintImpl
