/**
 */
package base;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Artifact Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see base.Base_Package#getArtifactElement()
 * @model abstract="true"
 * @generated
 */
public interface ArtifactElement extends ModelElement {
} // ArtifactElement
