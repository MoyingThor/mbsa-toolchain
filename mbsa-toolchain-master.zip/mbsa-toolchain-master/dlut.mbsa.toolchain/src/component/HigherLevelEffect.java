/**
 */
package component;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Higher Level Effect</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see component.Component_Package#getHigherLevelEffect()
 * @model
 * @generated
 */
public interface HigherLevelEffect extends FailureEffect {
} // HigherLevelEffect
