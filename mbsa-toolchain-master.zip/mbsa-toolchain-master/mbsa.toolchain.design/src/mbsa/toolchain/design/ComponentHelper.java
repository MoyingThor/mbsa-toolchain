package mbsa.toolchain.design;

public class ComponentHelper {

}
