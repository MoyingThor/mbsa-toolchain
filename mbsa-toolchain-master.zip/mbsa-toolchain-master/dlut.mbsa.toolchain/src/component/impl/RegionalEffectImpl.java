/**
 */
package component.impl;

import component.Component_Package;
import component.RegionalEffect;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Regional Effect</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RegionalEffectImpl extends FailureEffectImpl implements RegionalEffect {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RegionalEffectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Component_Package.Literals.REGIONAL_EFFECT;
	}

} //RegionalEffectImpl
