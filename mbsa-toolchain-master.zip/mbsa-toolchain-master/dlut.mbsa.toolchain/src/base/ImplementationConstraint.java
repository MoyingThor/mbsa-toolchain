/**
 */
package base;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Implementation Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see base.Base_Package#getImplementationConstraint()
 * @model
 * @generated
 */
public interface ImplementationConstraint extends UtilityElement {
} // ImplementationConstraint
