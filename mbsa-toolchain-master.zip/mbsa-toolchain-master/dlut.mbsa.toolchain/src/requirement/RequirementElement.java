/**
 */
package requirement;

import base.ArtifactElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirement Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see requirement.Requirement_Package#getRequirementElement()
 * @model abstract="true"
 * @generated
 */
public interface RequirementElement extends ArtifactElement {
} // RequirementElement
