/**
 */
package component;

import base.ArtifactElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see component.Component_Package#getComponentElement()
 * @model abstract="true"
 * @generated
 */
public interface ComponentElement extends ArtifactElement {
} // ComponentElement
