/**
 */
package component;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Final Effect</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see component.Component_Package#getFinalEffect()
 * @model
 * @generated
 */
public interface FinalEffect extends FailureEffect {
} // FinalEffect
