/**
 */
package component;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component Asset</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see component.Component_Package#getComponentAsset()
 * @model abstract="true"
 * @generated
 */
public interface ComponentAsset extends ComponentElement {
} // ComponentAsset
