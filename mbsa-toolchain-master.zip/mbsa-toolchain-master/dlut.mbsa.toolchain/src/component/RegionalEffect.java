/**
 */
package component;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Regional Effect</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see component.Component_Package#getRegionalEffect()
 * @model
 * @generated
 */
public interface RegionalEffect extends FailureEffect {
} // RegionalEffect
